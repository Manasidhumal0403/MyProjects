package com.manasi.hospitalmanagement_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalmanagementSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
