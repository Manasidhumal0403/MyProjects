package com.manasi.hospitalmanagement_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalmanagementSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalmanagementSpringbootApplication.class, args);
	}

}
